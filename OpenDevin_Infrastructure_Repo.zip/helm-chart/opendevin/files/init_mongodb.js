
db = db.getSiblingDB("opendevin");
db.createCollection("tasks");
db.tasks.createIndex({ "status": 1 });
