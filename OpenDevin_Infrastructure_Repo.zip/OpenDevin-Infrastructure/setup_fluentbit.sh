#!/bin/bash

# Install Fluent Bit for log shipping to external log service
curl -s https://packages.fluentbit.io/fluentbit.key | sudo apt-key add -
echo "deb https://packages.fluentbit.io/ubuntu/jammy jammy main" | sudo tee /etc/apt/sources.list.d/fluentbit.list
sudo apt update && sudo apt install -y td-agent-bit

# Example configuration to log to local file (replace with your remote log service)
cat <<EOF | sudo tee /etc/td-agent-bit/td-agent-bit.conf
[SERVICE]
    Flush        5
    Daemon       Off
    Log_Level    info

[INPUT]
    Name          tail
    Path          /var/log/syslog
    Tag           syslog

[OUTPUT]
    Name          stdout
    Match         *
EOF

sudo systemctl restart td-agent-bit
