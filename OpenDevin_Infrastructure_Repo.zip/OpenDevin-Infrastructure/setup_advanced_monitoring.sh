#!/bin/bash

# Update and install dependencies
sudo apt update && sudo apt install -y unzip curl wget jq

# Install Azure Monitor Agent (AMA)
wget https://aka.ms/InstallAzureMonitorLinuxAgent -O InstallAzureMonitorLinuxAgent.sh
chmod +x InstallAzureMonitorLinuxAgent.sh
sudo ./InstallAzureMonitorLinuxAgent.sh

# Install Node Exporter for Prometheus
useradd --no-create-home --shell /bin/false node_exporter
wget https://github.com/prometheus/node_exporter/releases/download/v1.7.0/node_exporter-1.7.0.linux-amd64.tar.gz
tar xvfz node_exporter-1.7.0.linux-amd64.tar.gz
cp node_exporter-1.7.0.linux-amd64/node_exporter /usr/local/bin/
chown node_exporter:node_exporter /usr/local/bin/node_exporter

# Create systemd service
cat <<EOF | sudo tee /etc/systemd/system/node_exporter.service
[Unit]
Description=Node Exporter
After=network.target

[Service]
User=node_exporter
Group=node_exporter
Type=simple
ExecStart=/usr/local/bin/node_exporter

[Install]
WantedBy=default.target
EOF

# Enable and start Node Exporter
sudo systemctl daemon-reexec
sudo systemctl daemon-reload
sudo systemctl enable node_exporter
sudo systemctl start node_exporter

# Install and configure custom alerts (placeholder)
echo "Configure Prometheus/Grafana to collect from port 9100 on this VM."

# Instructions for Grafana Setup (Optional)
echo "To use Grafana, deploy a Grafana server and add this node's IP:9100 as a Prometheus data source."
echo "You can now monitor OpenDevin system metrics using Azure Monitor and Node Exporter (port 9100)."

