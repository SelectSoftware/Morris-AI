#!/bin/bash

# Update system
sudo apt update && sudo apt upgrade -y

# Install dependencies
sudo apt install -y git curl docker.io docker-compose nodejs npm python3-pip

# Start and enable Docker
sudo systemctl start docker
sudo systemctl enable docker

# Add user to Docker group
sudo usermod -aG docker $USER

# Clone OpenDevin repository
git clone https://github.com/OpenDevin/OpenDevin.git
cd OpenDevin

# Copy environment file and prompt user to edit it manually later
cp .env.example .env

echo "Setup complete. Please SSH into the VM and edit the .env file with your OpenAI API key."
echo "Then run: docker-compose up --build"
