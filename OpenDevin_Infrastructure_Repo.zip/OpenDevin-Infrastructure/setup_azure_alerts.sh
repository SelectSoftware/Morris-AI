#!/bin/bash

# This script creates an alert rule on Azure using Azure CLI (assumes az login already done)
# Replace with your actual Resource Group and VM Name

RESOURCE_GROUP="opendevin-rg"
VM_NAME="opendevin-vm"
ACTION_GROUP_NAME="OpenDevinAlerts"
PHONE_NUMBER="+1YOURNUMBER"

# Create Action Group for SMS
az monitor action-group create   --resource-group $RESOURCE_GROUP   --name $ACTION_GROUP_NAME   --short-name "OpenDevinAG"   --action phone myPhoneAlert $PHONE_NUMBER

# Create CPU usage alert
az monitor metrics alert create   --name "HighCPUAlert"   --resource-group $RESOURCE_GROUP   --scopes $(az vm show -g $RESOURCE_GROUP -n $VM_NAME --query id -o tsv)   --condition "avg Percentage CPU > 80"   --description "CPU usage exceeds 80%"   --action-groups $ACTION_GROUP_NAME

echo "Alerts and SMS trigger created for high CPU usage."
